<p>Your login URL: <a href="{{ $loginUrl }}">{{ $loginUrl }}</a></p>
